package com.api.automation.getRequest;

import com.intuit.karate.junit5.Karate;
import com.intuit.karate.junit5.Karate.Test;

public class variableRunner {

	@Test
	public Karate runVariables()
	{
		return Karate.run("variables").relativeTo(getClass());
	}
	
}
