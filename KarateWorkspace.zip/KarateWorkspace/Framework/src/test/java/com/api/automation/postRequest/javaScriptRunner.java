package com.api.automation.postRequest;

import com.intuit.karate.junit5.Karate;
import com.intuit.karate.junit5.Karate.Test;

public class javaScriptRunner {

	
	@Test	
	public Karate runJavaScript()
	 {
		return Karate.run("javaScriptFunction").relativeTo(getClass());
	 }

}
