package com.api.automation.getRequest;

import com.intuit.karate.junit5.Karate;
import com.intuit.karate.junit5.Karate.Test;

public class TestRunner {
	
	@Test
	public Karate runTest1()
	{
		return Karate.run("getRequest","responseMatcher","JsonArrayValidation").relativeTo(getClass());
	}
	
	
//	@Test
	public Karate runTest2()
	{
		return Karate.run("classpath:com/api/automation/getRequest/getRequest.feature");
	}

}
